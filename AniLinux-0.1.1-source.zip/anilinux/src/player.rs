//! External players. mpv confirms actual playback over its private JSON IPC socket.
use crate::{
    network,
    resolver::{installed, Media},
};
use serde_json::{json, Value};
use std::{os::unix::fs::PermissionsExt, path::Path, process::Stdio, time::Duration};
use tokio::{
    io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader},
    net::UnixStream,
    process::{Child, Command},
};

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Failure {
    Resolve,
    MissingPlayer,
    Launch,
    Open,
    Timeout,
    Headers,
    LocalFile,
}
impl Failure {
    pub fn message(&self) -> &'static str {
        match self {
            Self::Resolve => "No se pudo obtener el vídeo de este servidor. Prueba con otro servidor.",
            Self::MissingPlayer => "No se encontró el reproductor seleccionado. Elige mpv o VLC instalado en Opciones.",
            Self::Launch => "No se pudo iniciar el reproductor. Comprueba que pueda abrirse desde tu sesión de escritorio.",
            Self::Open => "El reproductor no pudo abrir el vídeo. Prueba otro servidor o reproduce un vídeo local para comprobarlo.",
            Self::Timeout => "El reproductor no confirmó la reproducción a tiempo. Comprueba la conexión y prueba otro servidor.",
            Self::Headers => "Este servidor necesita mpv. Selecciónalo en Opciones.",
            Self::LocalFile => "El archivo local ya no está disponible o no se puede leer.",
        }
    }
}
impl std::fmt::Display for Failure {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.message())
    }
}
impl std::error::Error for Failure {}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Confirmation {
    /// IPC playback-restart: mpv started playback, not just a running process.
    Playing,
    /// VLC/xdg-open launched; no claim that video frames have been displayed.
    Launched,
}
fn choose(preference: &str) -> Result<&str, Failure> {
    if preference != "auto" {
        if !["mpv", "vlc", "xdg-open"].contains(&preference) || !installed(preference) {
            return Err(Failure::MissingPlayer);
        }
        return Ok(preference);
    }
    ["mpv", "vlc", "xdg-open"]
        .into_iter()
        .find(|p| installed(p))
        .ok_or(Failure::MissingPlayer)
}
fn software_mode() -> bool {
    std::env::var("LIBGL_ALWAYS_SOFTWARE").is_ok_and(|v| v == "1" || v.eq_ignore_ascii_case("true"))
}
fn mpv_command(socket: &Path, media: Option<&Media>, software: bool) -> Command {
    let mut cmd = Command::new("mpv");
    cmd.arg("--idle=once")
        .arg("--force-window=immediate")
        .arg("--network-timeout=30")
        .arg("--msg-level=all=warn")
        .arg(format!("--input-ipc-server={}", socket.display()));
    if software {
        cmd.args(["--hwdec=no", "--vo=gpu", "--gpu-api=opengl", "--gpu-sw=yes"]);
    }
    if let Some(media) = media {
        let agent = media
            .headers
            .iter()
            .find(|(k, _)| k.eq_ignore_ascii_case("user-agent"))
            .map(|(_, v)| v.as_str())
            .unwrap_or(network::USER_AGENT);
        // mpv REQUIRES --option=value. '--referrer URL' is a fatal CLI error.
        cmd.arg(format!("--referrer={}", media.referer))
            .arg(format!("--user-agent={agent}"));
        let headers: Vec<_> = media
            .headers
            .iter()
            .filter(|(k, _)| !k.eq_ignore_ascii_case("user-agent"))
            .map(|(k, v)| {
                format!("{k}: {v}")
                    .replace('\\', "\\\\")
                    .replace(',', "\\,")
            })
            .collect();
        if !headers.is_empty() {
            cmd.arg(format!("--http-header-fields={}", headers.join(",")));
        }
    }
    cmd
}
async fn terminate(child: &mut Child) {
    let _ = child.kill().await;
    let _ = child.wait().await;
}

/// Wait for the IPC socket without blocking egui; opening the media happens only
/// AFTER connecting, so file-loaded/end-file/playback-restart cannot be missed.
async fn connect(child: &mut Child, socket: &Path) -> Result<UnixStream, Failure> {
    let deadline = tokio::time::Instant::now() + Duration::from_secs(8);
    loop {
        match UnixStream::connect(socket).await {
            Ok(stream) => return Ok(stream),
            Err(e)
                if !matches!(
                    e.kind(),
                    std::io::ErrorKind::NotFound | std::io::ErrorKind::ConnectionRefused
                ) =>
            {
                return Err(Failure::Launch)
            }
            Err(_) => {}
        }
        if child.try_wait().map_err(|_| Failure::Launch)?.is_some() {
            return Err(Failure::Launch);
        }
        if tokio::time::Instant::now() >= deadline {
            return Err(Failure::Timeout);
        }
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
}
#[derive(PartialEq, Debug)]
enum Signal {
    Waiting,
    Playing,
    Failed,
}
fn signal(event: &Value) -> Signal {
    if event["event"] == "playback-restart" {
        return Signal::Playing;
    }
    if event["event"] == "end-file" && event["reason"] != "redirect" {
        return Signal::Failed;
    }
    if event["request_id"] == 1 && event["error"].as_str().is_some_and(|e| e != "success") {
        return Signal::Failed;
    }
    Signal::Waiting
}
async fn confirm(child: &mut Child, stream: &mut UnixStream, source: &str) -> Result<(), Failure> {
    let command =
        json!({"command":["loadfile",source,"replace"],"request_id":1}).to_string() + "\n";
    stream
        .write_all(command.as_bytes())
        .await
        .map_err(|_| Failure::Open)?;
    let mut reader = BufReader::new(stream);
    let wait = async {
        loop {
            // Bounded IPC messages even with unexpected metadata.
            let mut bytes = Vec::new();
            let mut limited = (&mut reader).take(256 * 1024);
            let n = tokio::select! {
                status = child.wait() => { let _ = status; return Err(Failure::Open); },
                n = limited.read_until(b'\n', &mut bytes) => n.map_err(|_| Failure::Open)?,
            };
            if n == 0 || n >= 256 * 1024 {
                return Err(Failure::Open);
            }
            let Ok(event) = serde_json::from_slice::<Value>(&bytes) else {
                continue;
            };
            match signal(&event) {
                Signal::Playing => return Ok(()),
                Signal::Failed => return Err(Failure::Open),
                Signal::Waiting => {}
            }
        }
    };
    tokio::time::timeout(Duration::from_secs(45), wait)
        .await
        .map_err(|_| Failure::Timeout)?
}
async fn mpv(source: &str, media: Option<&Media>) -> Result<Confirmation, Failure> {
    let dir = tempfile::Builder::new()
        .prefix("anilinux-player-")
        .tempdir()
        .map_err(|_| Failure::Launch)?;
    std::fs::set_permissions(dir.path(), std::fs::Permissions::from_mode(0o700))
        .map_err(|_| Failure::Launch)?;
    let socket = dir.path().join("ipc.sock");
    let mut child = mpv_command(&socket, media, software_mode())
        .stdin(Stdio::null())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .spawn()
        .map_err(|e| {
            eprintln!("AniLinux: no se pudo iniciar mpv: {e}");
            Failure::Launch
        })?;
    let result = async {
        let mut stream = connect(&mut child, &socket).await?;
        confirm(&mut child, &mut stream, source).await?;
        Ok::<_, Failure>(stream)
    }
    .await;
    match result {
        Ok(mut stream) => {
            tokio::spawn(async move {
                // Drain subscribed events until exit; keep the private socket alive.
                let mut sink = tokio::io::sink();
                tokio::select! {
                    _ = child.wait() => {},
                    _ = tokio::io::copy(&mut stream, &mut sink) => { let _ = child.wait().await; },
                }
                drop(dir);
            });
            Ok(Confirmation::Playing)
        }
        Err(error) => {
            terminate(&mut child).await;
            Err(error)
        }
    }
}
async fn launch_unconfirmed(
    mut command: Command,
    is_opener: bool,
) -> Result<Confirmation, Failure> {
    // Do not suppress diagnostics and do not reuse an invisible VLC instance.
    let mut child = command
        .stdin(Stdio::null())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .spawn()
        .map_err(|e| {
            eprintln!("AniLinux: no se pudo iniciar el reproductor: {e}");
            Failure::Launch
        })?;
    tokio::time::sleep(Duration::from_secs(2)).await;
    if let Some(status) = child.try_wait().map_err(|_| Failure::Launch)? {
        if !status.success() || !is_opener {
            return Err(Failure::Open);
        }
    } else {
        tokio::spawn(async move {
            let _ = child.wait().await;
        });
    }
    Ok(Confirmation::Launched)
}
fn vlc_command(media: Option<&Media>, source: &str) -> Result<Command, Failure> {
    let mut cmd = Command::new("vlc");
    cmd.arg("--no-one-instance")
        .arg("--no-playlist-enqueue")
        .arg("--play-and-exit");
    if software_mode() {
        cmd.arg("--avcodec-hw=none");
    }
    if let Some(media) = media {
        if !media
            .headers
            .keys()
            .all(|k| k.eq_ignore_ascii_case("user-agent"))
        {
            return Err(Failure::Headers);
        }
        let agent = media
            .headers
            .iter()
            .find(|(k, _)| k.eq_ignore_ascii_case("user-agent"))
            .map(|(_, v)| v.as_str())
            .unwrap_or(network::USER_AGENT);
        cmd.arg(format!("--http-referrer={}", media.referer))
            .arg(format!("--http-user-agent={agent}"));
    }
    cmd.arg("--").arg(source);
    Ok(cmd)
}
pub async fn play(media: &Media, preference: &str) -> Result<Confirmation, Failure> {
    network::web_url(&media.url).map_err(|_| Failure::Resolve)?;
    match choose(preference)? {
        "mpv" => mpv(&media.url, Some(media)).await,
        "vlc" => launch_unconfirmed(vlc_command(Some(media), &media.url)?, false).await,
        _ => Err(Failure::Headers),
    }
}
pub async fn play_file(path: &Path, preference: &str) -> Result<Confirmation, Failure> {
    let path = tokio::fs::canonicalize(path)
        .await
        .map_err(|_| Failure::LocalFile)?;
    if !tokio::fs::metadata(&path)
        .await
        .map_err(|_| Failure::LocalFile)?
        .is_file()
    {
        return Err(Failure::LocalFile);
    }
    let source = path.to_str().ok_or(Failure::LocalFile)?;
    match choose(preference)? {
        "mpv" => mpv(source, None).await,
        "vlc" => launch_unconfirmed(vlc_command(None, source)?, false).await,
        _ => {
            let mut cmd = Command::new("xdg-open");
            cmd.arg(&path);
            launch_unconfirmed(cmd, true).await
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::resolver::MediaKind;
    #[test]
    fn mpv_options_use_equals_not_separate_arguments() {
        let media = Media {
            url: "https://example.org/video.mp4".into(),
            referer: "https://example.org/watch".into(),
            headers: Default::default(),
            kind: MediaKind::Direct,
        };
        let cmd = mpv_command(Path::new("/tmp/private/ipc.sock"), Some(&media), true);
        let args: Vec<_> = cmd
            .as_std()
            .get_args()
            .map(|a| a.to_string_lossy().into_owned())
            .collect();
        assert!(args.contains(&"--referrer=https://example.org/watch".into()));
        assert!(args.contains(&format!("--user-agent={}", network::USER_AGENT)));
        assert!(args.contains(&"--hwdec=no".into()));
        assert!(args.contains(&"--gpu-sw=yes".into()));
        assert!(!args.contains(&"--referrer".into()));
        assert!(!args.contains(&"--user-agent".into()));
        assert!(!args.contains(&media.url)); // Sent only after IPC connection.
    }
    #[test]
    fn process_running_or_loadfile_ack_is_not_playback_confirmation() {
        assert_eq!(
            signal(&json!({"error":"success","request_id":1})),
            Signal::Waiting
        );
        assert_eq!(signal(&json!({"event":"file-loaded"})), Signal::Waiting);
        assert_eq!(
            signal(&json!({"event":"playback-restart"})),
            Signal::Playing
        );
        assert_eq!(
            signal(&json!({"event":"end-file","reason":"error"})),
            Signal::Failed
        );
    }
    #[test]
    fn vlc_starts_a_new_instance() {
        let cmd = vlc_command(None, "/tmp/test.mp4").expect("local VLC command");
        assert!(cmd.as_std().get_args().any(|a| a == "--no-one-instance"));
    }
}
