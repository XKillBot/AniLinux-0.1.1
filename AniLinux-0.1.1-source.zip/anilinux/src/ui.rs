use crate::{
    downloader,
    extension_manager::{self, Definition, Manifest},
    images::Images,
    models::*,
    tasks::{Bus, Event, Tasks},
};
use egui::{Color32, RichText, Vec2};
use std::{
    collections::{HashMap, HashSet},
    sync::{mpsc, Arc, Mutex},
    time::{Duration, Instant},
};
use tokio::runtime::Handle;
use tokio_util::sync::CancellationToken;

const BG: Color32 = Color32::from_rgb(25, 25, 46);
const PANEL: Color32 = Color32::from_rgb(32, 32, 54);
const CARD: Color32 = Color32::from_rgb(41, 41, 63);
const CYAN: Color32 = Color32::from_rgb(0, 216, 222);
const MUTED: Color32 = Color32::from_rgb(162, 165, 187);
#[derive(Clone, Copy, PartialEq)]
enum Page {
    Home,
    Catalog,
    Releases,
    Downloads,
    Settings,
    Detail,
}
struct Picker {
    anime: Anime,
    episode: Episode,
    sources: Option<Sources>,
    language: String,
    index: usize,
    download_tab: bool,
}

pub struct AniLinux {
    tasks: Tasks,
    rx: mpsc::Receiver<Event>,
    definition: Definition,
    state: LocalState,
    final_state: Arc<Mutex<LocalState>>,
    page: Page,
    browse: Browse,
    catalog: Catalog,
    detail: Option<Anime>,
    picker: Option<Picker>,
    search: String,
    folder: String,
    images: Images,
    catalog_seq: u64,
    detail_seq: u64,
    sources_seq: u64,
    loading: bool,
    detail_loading: bool,
    update: Option<Manifest>,
    applying: bool,
    update_notice: String,
    notice: Option<(String, Instant)>,
    error: Option<String>,
    jobs: HashMap<String, CancellationToken>,
    quick_pending: HashSet<String>,
    playing: bool,
    show_episodes: bool,
    descending: bool,
    dirty: bool,
    saved: Instant,
}
impl AniLinux {
    pub fn new(
        cc: &eframe::CreationContext<'_>,
        handle: Handle,
        client: reqwest::Client,
        state: LocalState,
        final_state: Arc<Mutex<LocalState>>,
    ) -> anyhow::Result<Self> {
        let mut visuals = egui::Visuals::dark();
        visuals.override_text_color = Some(Color32::from_rgb(225, 228, 240));
        visuals.panel_fill = BG;
        visuals.window_fill = PANEL;
        visuals.extreme_bg_color = BG;
        visuals.selection.bg_fill = Color32::from_rgb(0, 86, 100);
        visuals.selection.stroke.color = CYAN;
        visuals.widgets.inactive.bg_fill = CARD;
        visuals.widgets.hovered.bg_fill = Color32::from_rgb(53, 57, 80);
        visuals.widgets.active.bg_fill = Color32::from_rgb(0, 100, 116);
        cc.egui_ctx.set_visuals(visuals);
        let mut style = (*cc.egui_ctx.style()).clone();
        style.spacing.item_spacing = egui::vec2(12.0, 12.0);
        style.spacing.button_padding = egui::vec2(14.0, 10.0);
        style
            .text_styles
            .insert(egui::TextStyle::Body, egui::FontId::proportional(16.0));
        style
            .text_styles
            .insert(egui::TextStyle::Button, egui::FontId::proportional(15.0));
        cc.egui_ctx.set_style(style);
        let (tx, rx) = mpsc::channel();
        let tasks = Tasks::new(
            handle,
            client,
            Bus {
                tx,
                ctx: cc.egui_ctx.clone(),
            },
        );
        tasks.startup();
        Ok(Self {
            folder: state.settings.download_dir.to_string_lossy().into_owned(),
            tasks,
            rx,
            definition: extension_manager::bundled()?,
            state,
            final_state,
            page: Page::Home,
            browse: Browse {
                home: true,
                page: 1,
                ..Default::default()
            },
            catalog: Catalog::default(),
            detail: None,
            picker: None,
            search: String::new(),
            images: Images::default(),
            catalog_seq: 0,
            detail_seq: 0,
            sources_seq: 0,
            loading: true,
            detail_loading: false,
            update: None,
            applying: false,
            update_notice: String::new(),
            notice: None,
            error: None,
            jobs: HashMap::new(),
            quick_pending: HashSet::new(),
            playing: false,
            show_episodes: true,
            descending: false,
            dirty: false,
            saved: Instant::now(),
        })
    }
    fn toast(&mut self, message: &str) {
        self.notice = Some((message.into(), Instant::now()));
    }
    fn refresh(&mut self) {
        self.catalog_seq += 1;
        self.loading = true;
        self.error = None;
        self.tasks.browse(
            self.catalog_seq,
            self.definition.clone(),
            self.browse.clone(),
        );
    }
    fn navigate(&mut self, page: Page) {
        self.page = page;
        self.picker = None;
        self.sources_seq += 1;
        if matches!(page, Page::Home | Page::Catalog | Page::Releases) {
            self.browse = Browse {
                home: page == Page::Home,
                airing: page == Page::Releases,
                page: 1,
                ..Default::default()
            };
            self.search.clear();
            self.refresh();
        }
    }
    fn search(&mut self) {
        self.page = Page::Catalog;
        self.browse = Browse {
            search: self.search.trim().into(),
            page: 1,
            ..Default::default()
        };
        if !self.browse.search.is_empty() {
            self.state.searches.retain(|s| s != &self.browse.search);
            self.state.searches.insert(0, self.browse.search.clone());
            self.state.searches.truncate(8);
            self.dirty = true;
        }
        self.refresh();
    }
    fn open(&mut self, a: Anime) {
        self.detail_seq += 1;
        self.detail_loading = true;
        self.error = None;
        self.tasks
            .detail(self.detail_seq, self.definition.clone(), a.url.clone());
        self.detail = Some(a);
        self.page = Page::Detail;
        self.show_episodes = true;
    }
    fn pick(&mut self, anime: Anime, episode: Episode) {
        self.sources_seq += 1;
        self.tasks.sources(
            self.sources_seq,
            self.definition.clone(),
            episode.clone(),
            None,
        );
        self.picker = Some(Picker {
            anime,
            episode,
            sources: None,
            language: String::new(),
            index: 0,
            download_tab: false,
        });
    }
    fn quick_download(&mut self, anime: Anime, episode: Episode) {
        if self.quick_pending.insert(episode.url.clone()) {
            self.tasks
                .sources(0, self.definition.clone(), episode, Some(anime));
            self.toast("Preparando descarga…");
        }
    }
    fn download(&mut self, a: Anime, ep: Episode, server: Server, lang: String) {
        let root = self.state.settings.download_dir.clone();
        if !root.is_absolute() {
            self.toast("Elige una carpeta de descarga válida en Opciones.");
            return;
        }
        let key = downloader::key(&ep.url, &lang);
        if self.jobs.contains_key(&key) {
            self.toast("Este episodio ya está en la cola.");
            return;
        }
        if self
            .state
            .downloads
            .iter()
            .any(|j| j.key == key && j.status == DownloadStatus::Complete)
        {
            self.toast("Este episodio ya está descargado.");
            return;
        }
        self.state.downloads.retain(|j| j.key != key);
        self.state.downloads.push(Download {
            key: key.clone(),
            title: a.title.clone(),
            episode: format!("Episodio {}", ep.number),
            language: lang.clone(),
            path: Default::default(),
            progress: None,
            status: DownloadStatus::Queued,
        });
        let cancel = CancellationToken::new();
        self.jobs.insert(key.clone(), cancel.clone());
        self.tasks.download(
            self.definition.clone(),
            a,
            ep,
            server,
            lang,
            root,
            key,
            cancel,
        );
        self.dirty = true;
        self.toast("Episodio añadido a descargas.");
    }
    fn cancel_episode(&mut self, ep: &Episode) {
        for lang in ["SUB", "DUB"] {
            if let Some(c) = self.jobs.get(&downloader::key(&ep.url, lang)) {
                c.cancel();
            }
        }
    }
    fn poll(&mut self) {
        while let Ok(event) = self.rx.try_recv() {
            match event {
                Event::Boot(d) => { self.definition = d; self.refresh(); }
                Event::Catalog(id, result) if id == self.catalog_seq => {
                    self.loading = false;
                    match result {
                        Ok(c) => self.catalog = c,
                        Err(_) => self.error = Some("No se pudo cargar el catálogo. Comprueba tu conexión o vuelve a intentarlo más tarde.".into()),
                    }
                }
                Event::Detail(id,result) if id == self.detail_seq => {
                    self.detail_loading = false;
                    match result { Ok(a) => self.detail = Some(a), Err(_) => self.error = Some("No se pudo abrir esta ficha. Vuelve a intentarlo o comprueba las actualizaciones de la fuente.".into()) }
                }
                Event::Sources(id,result) if id == self.sources_seq => {
                    match result {
                        Ok(s) => if let Some(p) = &mut self.picker {
                            p.language = s.languages().first().cloned().unwrap_or_default(); p.sources = Some(s);
                        },
                        Err(_) => { self.picker = None; self.toast("Este episodio no tiene servidores disponibles o no se pudo consultar."); }
                    }
                }
                Event::Quick(a,ep,result) => {
                    self.quick_pending.remove(&ep.url);
                    if let Ok(s) = result {
                        if let Some(lang) = s.languages().first().cloned() {
                            if let Some(server) = s.preferred(&lang) { self.download(a, ep, server, lang); }
                        }
                    } else { self.toast("No se pudo preparar la descarga. Prueba otro episodio o servidor."); }
                }
                Event::Update(m) => self.update = m,
                Event::UpdateFailed => self.update_notice = "No se pudieron comprobar las actualizaciones. La fuente local sigue disponible.".into(),
                Event::Applied(result) => {
                    self.applying = false;
                    match result {
                        Ok(d) => {
                            self.definition = d; self.update = None; self.update_notice.clear();
                            self.sources_seq += 1; self.picker = None; self.detail_seq += 1; self.detail_loading = false;
                            if self.page == Page::Detail {
                                if let Some(a) = self.detail.clone() { self.open(a); }
                            } else { self.refresh(); }
                            self.toast("Fuente actualizada. Ya puedes seguir explorando.");
                        }
                        Err(_) => self.toast("No se pudo aplicar la actualización. Se conserva la fuente anterior."),
                    }
                }
                Event::Played(history, result) => {
                    self.playing = false;
                    match result {
                        Ok(confirmation) => {
                            self.state.history.retain(|h| h.anime.slug != history.anime.slug);
                            self.state.history.insert(0,history); self.state.history.truncate(100); self.dirty = true;
                            self.toast(match confirmation {
                                crate::player::Confirmation::Playing => "Reproducción iniciada en mpv.",
                                crate::player::Confirmation::Launched => "VLC iniciado. No se ha confirmado la reproducción del vídeo.",
                            });
                        }
                        Err(error) => self.toast(error.message()),
                    }
                }
                Event::FilePlayed(result) => match result {
                    Ok(crate::player::Confirmation::Playing) => self.toast("Reproducción iniciada en mpv."),
                    Ok(crate::player::Confirmation::Launched) => self.toast("Solicitud enviada a la aplicación de vídeo."),
                    Err(error) => self.toast(error.message()),
                },
                Event::Planned(key,path) => if let Some(j) = self.state.downloads.iter_mut().find(|j| j.key == key) {
                    j.path = path; j.status = DownloadStatus::Running; self.dirty = true;
                },
                Event::Progress(key,p) => if let Some(j) = self.state.downloads.iter_mut().find(|j| j.key == key) { j.progress = p; },
                Event::Finished(key,ok,cancelled) => {
                    self.jobs.remove(&key);
                    if let Some(j) = self.state.downloads.iter_mut().find(|j| j.key == key) {
                        j.status = if cancelled { DownloadStatus::Cancelled } else if ok { DownloadStatus::Complete } else { DownloadStatus::Failed };
                        if ok { j.progress = Some(1.0); }
                    }
                    self.dirty = true;
                    self.toast(if cancelled { "Descarga cancelada." } else if ok { "Descarga terminada. Disponible sin conexión." } else { "No se pudo descargar. Prueba otro servidor y comprueba yt-dlp, FFmpeg y el espacio disponible." });
                }
                Event::SaveFailed => self.toast("No se pudieron guardar los cambios locales. Comprueba el espacio y los permisos."),
                _ => {}
            }
        }
    }
    fn image(&mut self, ui: &mut egui::Ui, url: &str, size: Vec2) {
        if let Some(texture) =
            self.images
                .get(url, ui.ctx(), &self.tasks.handle, &self.tasks.client)
        {
            // Center crop rather than stretch the cover.
            let original = texture.size_vec2();
            let target_aspect = size.x / size.y;
            let image_aspect = original.x / original.y;
            let uv = if image_aspect > target_aspect {
                let w = target_aspect / image_aspect;
                egui::Rect::from_min_max(
                    egui::pos2((1.0 - w) / 2.0, 0.0),
                    egui::pos2((1.0 + w) / 2.0, 1.0),
                )
            } else {
                let h = image_aspect / target_aspect;
                egui::Rect::from_min_max(
                    egui::pos2(0.0, (1.0 - h) / 2.0),
                    egui::pos2(1.0, (1.0 + h) / 2.0),
                )
            };
            ui.add(
                egui::Image::new(&texture)
                    .uv(uv)
                    .fit_to_exact_size(size)
                    .maintain_aspect_ratio(false)
                    .corner_radius(8),
            );
        } else {
            let (rect, _) = ui.allocate_exact_size(size, egui::Sense::hover());
            ui.painter()
                .rect_filled(rect, 8, Color32::from_rgb(48, 49, 73));
            ui.painter().circle_stroke(
                rect.center(),
                17.0,
                egui::Stroke::new(2.0_f32, Color32::from_rgb(75, 79, 105)),
            );
            ui.painter().text(
                rect.center(),
                egui::Align2::CENTER_CENTER,
                "A",
                egui::FontId::proportional(17.0),
                MUTED,
            );
        }
    }
    fn card(&mut self, ui: &mut egui::Ui, anime: &Anime, width: f32) -> bool {
        let mut clicked = false;
        ui.push_id(&anime.slug, |ui| {
            let response = egui::Frame::new()
                .fill(CARD)
                .corner_radius(12)
                .inner_margin(8)
                .show(ui, |ui| {
                    ui.with_layout(egui::Layout::top_down(egui::Align::Min), |ui| {
                        ui.set_width(width - 16.0);
                        self.image(
                            ui,
                            &anime.cover,
                            egui::vec2(width - 16.0, (width - 16.0) * 1.38),
                        );
                        if let Some(badge) = &anime.badge {
                            ui.label(RichText::new(badge).size(11.0).strong().color(CYAN));
                        } else {
                            ui.label(
                                RichText::new(anime.kind.as_deref().unwrap_or("ANIME"))
                                    .size(11.0)
                                    .color(MUTED),
                            );
                        }
                        let mut text = egui::text::LayoutJob::simple(
                            anime.title.clone(),
                            egui::FontId::proportional(14.0),
                            Color32::from_rgb(225, 228, 240),
                            width - 16.0,
                        );
                        text.wrap.max_rows = 2;
                        ui.allocate_ui_with_layout(
                            egui::vec2(width - 16.0, 40.0),
                            egui::Layout::top_down(egui::Align::Min),
                            |ui| {
                                ui.set_min_height(40.0);
                                ui.label(text);
                            },
                        );
                    });
                })
                .response;
            clicked = response
                .interact(egui::Sense::click())
                .on_hover_text(&anime.title)
                .clicked();
        });
        clicked
    }
    fn cards(&mut self, ui: &mut egui::Ui, items: &[Anime], horizontal: bool, id: &str) {
        let mut selected = None;
        if horizontal {
            egui::ScrollArea::horizontal().id_salt(id).show(ui, |ui| {
                ui.horizontal_top(|ui| {
                    for item in items {
                        if self.card(ui, item, 164.0) {
                            selected = Some(item.clone());
                        }
                    }
                });
            });
        } else {
            let columns = ((ui.available_width() + 12.0) / 176.0).floor().max(1.0) as usize;
            let width =
                ((ui.available_width() - (columns - 1) as f32 * 12.0) / columns as f32).min(230.0);
            for row in items.chunks(columns) {
                ui.horizontal_top(|ui| {
                    for item in row {
                        if self.card(ui, item, width) {
                            selected = Some(item.clone());
                        }
                    }
                });
                ui.add_space(8.0);
            }
        }
        if let Some(a) = selected {
            self.open(a);
        }
    }
    fn sidebar(&mut self, ctx: &egui::Context) {
        let narrow = ctx.screen_rect().width() < 850.0;
        egui::SidePanel::left("navigation")
            .resizable(false)
            .exact_width(if narrow { 142.0 } else { 198.0 })
            .frame(egui::Frame::new().fill(PANEL).inner_margin(16))
            .show(ctx, |ui| {
                ui.add_space(10.0);
                ui.label(
                    RichText::new("AniLinux")
                        .size(if narrow { 25.0 } else { 30.0 })
                        .strong()
                        .color(CYAN),
                );
                ui.label(RichText::new("Tu anime, en Linux").size(11.0).color(MUTED));
                ui.add_space(38.0);
                for (page, label) in [
                    (Page::Home, "Inicio"),
                    (Page::Catalog, "Catálogo"),
                    (Page::Releases, "En emisión"),
                    (Page::Downloads, "Descargas"),
                    (Page::Settings, "Opciones"),
                ] {
                    let button =
                        egui::Button::new(RichText::new(label).color(if self.page == page {
                            CYAN
                        } else {
                            Color32::from_rgb(217, 220, 233)
                        }))
                        .fill(if self.page == page {
                            Color32::from_rgb(32, 65, 77)
                        } else {
                            PANEL
                        });
                    if ui.add_sized([ui.available_width(), 44.0], button).clicked() {
                        self.navigate(page);
                    }
                }
                ui.with_layout(egui::Layout::bottom_up(egui::Align::LEFT), |ui| {
                    ui.label(RichText::new("AnimeAV1").size(12.0).color(MUTED));
                    if !self.jobs.is_empty() {
                        ui.label(
                            RichText::new(format!("{} en la cola", self.jobs.len()))
                                .size(12.0)
                                .color(CYAN),
                        );
                    }
                });
            });
    }
    fn header(&mut self, ctx: &egui::Context) {
        egui::TopBottomPanel::top("header")
            .frame(egui::Frame::new().fill(BG).inner_margin(18))
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    let title = match self.page {
                        Page::Home => "Inicio",
                        Page::Catalog => "Catálogo",
                        Page::Releases => "En emisión",
                        Page::Downloads => "Descargas",
                        Page::Settings => "Opciones",
                        Page::Detail => "Explorar",
                    };
                    ui.label(RichText::new(title).size(24.0).strong());
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button("Buscar").clicked() {
                            self.search();
                        }
                        let width = (ui.available_width() - 24.0).clamp(70.0, 320.0);
                        let response = ui.add_sized(
                            [width, 36.0],
                            egui::TextEdit::singleline(&mut self.search).hint_text("Buscar anime…"),
                        );
                        if response.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                            self.search();
                        }
                    });
                });
                if self.update.is_some() {
                    ui.add_space(10.0);
                    egui::Frame::new()
                        .fill(Color32::from_rgb(27, 63, 75))
                        .inner_margin(10)
                        .corner_radius(8)
                        .show(ui, |ui| {
                            ui.horizontal_wrapped(|ui| {
                                ui.label("Hay una actualización de la fuente disponible.");
                                if ui
                                    .add_enabled(
                                        !self.applying,
                                        egui::Button::new(if self.applying {
                                            "Actualizando…"
                                        } else {
                                            "Actualizar"
                                        }),
                                    )
                                    .clicked()
                                {
                                    if let Some(m) = self.update.clone() {
                                        self.applying = true;
                                        self.tasks.apply(m);
                                    }
                                }
                            });
                        });
                }
            });
    }
    fn browse_view(&mut self, ui: &mut egui::Ui) {
        let is_home = self.page == Page::Home;
        if !is_home {
            ui.horizontal_wrapped(|ui| {
                let mut genre = self.browse.genre.clone();
                let current = self
                    .catalog
                    .genres
                    .iter()
                    .find(|(id, _)| id == &genre)
                    .map(|(_, n)| n.as_str())
                    .unwrap_or("Todos los géneros");
                egui::ComboBox::from_id_salt("genres")
                    .selected_text(current)
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut genre, String::new(), "Todos los géneros");
                        for (id, name) in &self.catalog.genres {
                            ui.selectable_value(&mut genre, id.clone(), name);
                        }
                    });
                if genre != self.browse.genre {
                    self.browse.genre = genre;
                    self.browse.page = 1;
                    self.refresh();
                }
                if ui.button("Actualizar").clicked() {
                    self.refresh();
                }
                if !self.browse.search.is_empty() {
                    ui.label(
                        RichText::new(format!("Resultados para «{}»", self.browse.search))
                            .color(MUTED),
                    );
                }
            });
            if self.browse.search.is_empty() && !self.state.searches.is_empty() {
                let searches = self.state.searches.clone();
                ui.horizontal_wrapped(|ui| {
                    ui.label(RichText::new("Recientes").small().color(MUTED));
                    for s in searches.iter().take(5) {
                        if ui.small_button(s).clicked() {
                            self.search = s.clone();
                            self.search();
                        }
                    }
                    if ui.small_button("Borrar").clicked() {
                        self.state.searches.clear();
                        self.dirty = true;
                    }
                });
            }
            ui.add_space(12.0);
        }
        if self.loading {
            ui.horizontal(|ui| {
                ui.spinner();
                ui.label("Cargando…");
            });
        }
        if !self.loading && is_home && !self.state.history.is_empty() {
            ui.heading("Continuar viendo");
            ui.label(
                RichText::new("Episodios abiertos recientemente")
                    .small()
                    .color(MUTED),
            );
            let items: Vec<_> = self
                .state
                .history
                .iter()
                .take(12)
                .map(|h| {
                    let mut a = h.anime.clone();
                    a.badge = Some(format!("EP {}", h.episode.number));
                    a
                })
                .collect();
            self.cards(ui, &items, true, "history");
            ui.add_space(20.0);
        }
        if !self.loading {
            let sections = self.catalog.sections.clone();
            if sections.is_empty() && self.error.is_none() {
                ui.label("No se encontraron animes con estos filtros.");
            }
            for (index, (title, items)) in sections.iter().enumerate() {
                ui.horizontal(|ui| {
                    ui.label(RichText::new(title).size(23.0));
                    if is_home && ui.link(RichText::new("Ver catálogo").color(CYAN)).clicked() {
                        self.navigate(Page::Catalog);
                    }
                });
                self.cards(ui, items, is_home, &format!("section-{index}"));
                ui.add_space(22.0);
            }
            if !is_home && self.catalog.total_pages > 1 {
                ui.horizontal(|ui| {
                    if ui
                        .add_enabled(self.browse.page > 1, egui::Button::new("Anterior"))
                        .clicked()
                    {
                        self.browse.page -= 1;
                        self.refresh();
                    }
                    ui.label(format!(
                        "{} / {}",
                        self.catalog.page, self.catalog.total_pages
                    ));
                    if ui
                        .add_enabled(
                            self.browse.page < self.catalog.total_pages,
                            egui::Button::new("Siguiente"),
                        )
                        .clicked()
                    {
                        self.browse.page += 1;
                        self.refresh();
                    }
                });
            }
        }
    }
    fn detail_view(&mut self, ui: &mut egui::Ui) {
        if ui.button("Volver al catálogo").clicked() {
            self.navigate(Page::Catalog);
            return;
        }
        if self.detail_loading {
            ui.horizontal(|ui| {
                ui.spinner();
                ui.label("Abriendo ficha…");
            });
        }
        let Some(a) = self.detail.clone() else {
            return;
        };
        if !a.banner.is_empty() {
            self.image(ui, &a.banner, egui::vec2(ui.available_width(), 168.0));
        }
        ui.add_space(6.0);
        let compact = ui.available_width() < 540.0;
        ui.horizontal_top(|ui| {
            if !compact {
                self.image(ui, &a.cover, egui::vec2(155.0, 221.0));
            }
            ui.vertical(|ui| {
                ui.label(RichText::new(&a.title).size(27.0).strong());
                ui.horizontal_wrapped(|ui| {
                    for s in [
                        a.year.clone(),
                        a.kind.clone(),
                        (!a.episodes.is_empty()).then(|| format!("{} episodios", a.episodes.len())),
                    ]
                    .into_iter()
                    .flatten()
                    {
                        egui::Frame::new()
                            .fill(CARD)
                            .inner_margin(6)
                            .corner_radius(4)
                            .show(ui, |ui| {
                                ui.label(RichText::new(s).small().color(MUTED));
                            });
                    }
                });
                if !a.synopsis.is_empty() {
                    ui.add_space(6.0);
                    ui.label(RichText::new(&a.synopsis).color(Color32::from_rgb(193, 196, 214)));
                }
                ui.horizontal_wrapped(|ui| {
                    for genre in &a.genres {
                        egui::Frame::new()
                            .fill(CARD)
                            .inner_margin(7)
                            .corner_radius(18)
                            .show(ui, |ui| {
                                ui.label(RichText::new(genre).size(13.0));
                            });
                    }
                });
                let last = self
                    .state
                    .history
                    .iter()
                    .find(|h| h.anime.slug == a.slug)
                    .map(|h| h.episode.clone());
                ui.horizontal_wrapped(|ui| {
                    if let Some(ep) = last {
                        if ui
                            .button(
                                RichText::new(format!("Continuar · EP {}", ep.number)).color(CYAN),
                            )
                            .clicked()
                        {
                            self.pick(a.clone(), ep);
                        }
                    } else if let Some(ep) = a.episodes.first() {
                        if ui
                            .button(RichText::new("Ver primer episodio").color(CYAN))
                            .clicked()
                        {
                            self.pick(a.clone(), ep.clone());
                        }
                    }
                    if ui
                        .button(if self.show_episodes {
                            "Ocultar episodios"
                        } else {
                            "Ver episodios"
                        })
                        .clicked()
                    {
                        self.show_episodes = !self.show_episodes;
                    }
                });
            });
        });
        ui.add_space(22.0);
        if self.show_episodes {
            ui.horizontal(|ui| {
                ui.heading("Episodios");
                if ui
                    .button(if self.descending {
                        "Más recientes primero"
                    } else {
                        "Orden ascendente"
                    })
                    .clicked()
                {
                    self.descending = !self.descending;
                }
            });
            ui.label(RichText::new("Selecciona un episodio para elegir idioma y servidor. El interruptor inicia o cancela la descarga.").size(12.0).color(MUTED));
            if a.episodes.is_empty() && !self.detail_loading {
                ui.label("Aún no hay episodios publicados.");
            }
            let mut episodes = a.episodes.clone();
            if self.descending {
                episodes.reverse();
            }
            for ep in episodes {
                ui.push_id(&ep.url, |ui| {
                    let jobs: Vec<_> = self
                        .state
                        .downloads
                        .iter()
                        .filter(|j| {
                            [
                                downloader::key(&ep.url, "SUB"),
                                downloader::key(&ep.url, "DUB"),
                            ]
                            .contains(&j.key)
                        })
                        .collect();
                    let complete = jobs.iter().any(|j| j.status == DownloadStatus::Complete);
                    let active = jobs.iter().any(|j| {
                        matches!(j.status, DownloadStatus::Queued | DownloadStatus::Running)
                    });
                    let pending = self.quick_pending.contains(&ep.url);
                    let subtitle = if complete {
                        "Descargado"
                    } else if active {
                        "Descargando…"
                    } else if pending {
                        "Preparando…"
                    } else {
                        "Ver idiomas y servidores"
                    };
                    egui::Frame::new()
                        .fill(CARD)
                        .corner_radius(8)
                        .inner_margin(10)
                        .show(ui, |ui| {
                            ui.horizontal(|ui| {
                                if ui.available_width() > 460.0 {
                                    self.image(ui, &ep.thumbnail, egui::vec2(110.0, 62.0));
                                }
                                let name = if ep.title.is_empty() {
                                    format!("Episodio {}", ep.number)
                                } else {
                                    format!("{} · {}", ep.number, ep.title)
                                };
                                let response = ui.add_sized(
                                    [(ui.available_width() - 80.0).max(50.0), 62.0],
                                    egui::Button::new(
                                        RichText::new(format!("{name}\n{subtitle}")).color(CYAN),
                                    )
                                    .frame(false),
                                );
                                if response.clicked() {
                                    self.pick(a.clone(), ep.clone());
                                }
                                let mut enabled = complete || active || pending;
                                let response = ui
                                    .add_enabled_ui(!complete && !pending, |ui| {
                                        toggle(ui, &mut enabled)
                                    })
                                    .inner;
                                if response.changed() {
                                    if active {
                                        self.cancel_episode(&ep);
                                    } else {
                                        self.quick_download(a.clone(), ep.clone());
                                    }
                                }
                            });
                        });
                });
            }
        }
    }
    fn downloads_view(&mut self, ui: &mut egui::Ui) {
        ui.label(
            RichText::new("Tu biblioteca sin conexión")
                .size(25.0)
                .strong(),
        );
        ui.label(
            RichText::new(
                "Hasta 3 descargas simultáneas. Mantén AniLinux abierto hasta que terminen.",
            )
            .color(MUTED),
        );
        if self.state.downloads.is_empty() {
            ui.add_space(30.0);
            ui.label("Todavía no has descargado episodios.");
        }
        for job in self.state.downloads.clone().into_iter().rev() {
            egui::Frame::new()
                .fill(CARD)
                .inner_margin(16)
                .corner_radius(10)
                .show(ui, |ui| {
                    ui.set_width(ui.available_width());
                    ui.label(RichText::new(&job.title).strong());
                    ui.label(
                        RichText::new(format!("{} · {}", job.episode, job.language)).color(CYAN),
                    );
                    let status = match job.status {
                        DownloadStatus::Queued => "En cola",
                        DownloadStatus::Running => "Descargando",
                        DownloadStatus::Complete => "Disponible sin conexión",
                        DownloadStatus::Failed => "No se pudo descargar",
                        DownloadStatus::Cancelled => "Cancelada / interrumpida",
                    };
                    ui.horizontal_wrapped(|ui| {
                        ui.label(status);
                        if matches!(job.status, DownloadStatus::Queued | DownloadStatus::Running) {
                            if ui.button("Cancelar").clicked() {
                                if let Some(c) = self.jobs.get(&job.key) {
                                    c.cancel();
                                }
                            }
                        } else if job.status == DownloadStatus::Complete
                            && ui.button("Reproducir").clicked()
                        {
                            self.tasks
                                .play_file(job.path.clone(), self.state.settings.player.clone());
                        }
                        if !matches!(job.status, DownloadStatus::Queued | DownloadStatus::Running)
                            && ui.small_button("Quitar de la lista").clicked()
                        {
                            self.state.downloads.retain(|j| j.key != job.key);
                            self.dirty = true;
                        }
                    });
                    if job.status == DownloadStatus::Running {
                        if let Some(p) = job.progress {
                            ui.add(egui::ProgressBar::new(p).show_percentage().fill(CYAN));
                        } else {
                            ui.spinner();
                        }
                    }
                });
        }
        ui.label(
            RichText::new("Quitar de la lista no borra el vídeo guardado.")
                .small()
                .color(MUTED),
        );
    }
    fn settings_view(&mut self, ui: &mut egui::Ui) {
        ui.heading("Reproducción y descargas");
        ui.add_space(12.0);
        ui.label("Carpeta de descargas");
        ui.add(egui::TextEdit::singleline(&mut self.folder).desired_width(f32::INFINITY));
        if ui.button("Guardar carpeta").clicked() {
            let mut path = std::path::PathBuf::from(self.folder.trim());
            if let Some(suffix) = self.folder.trim().strip_prefix("~/") {
                if let Some(home) = dirs::home_dir() {
                    path = home.join(suffix);
                }
            }
            if path.is_absolute() {
                self.state.settings.download_dir = path;
                self.dirty = true;
                self.toast("Carpeta de descarga guardada.");
            } else {
                self.toast("Indica una carpeta con ruta absoluta, por ejemplo dentro de tu carpeta personal.");
            }
        }
        ui.add_space(18.0);
        ui.label("Reproductor");
        let old = self.state.settings.player.clone();
        egui::ComboBox::from_id_salt("player")
            .selected_text(if old == "auto" {
                "Automático (mpv / VLC)"
            } else {
                &old
            })
            .show_ui(ui, |ui| {
                for (value, label) in [
                    ("auto", "Automático (mpv / VLC)"),
                    ("mpv", "mpv"),
                    ("vlc", "VLC"),
                    ("xdg-open", "Aplicación predeterminada (archivos locales)"),
                ] {
                    ui.selectable_value(&mut self.state.settings.player, value.into(), label);
                }
            });
        if old != self.state.settings.player {
            self.dirty = true;
        }
        ui.add_space(24.0);
        ui.separator();
        ui.heading("Fuente de contenido");
        ui.label("AnimeAV1");
        if !self.update_notice.is_empty() {
            ui.label(RichText::new(&self.update_notice).color(MUTED));
        } else {
            ui.label(RichText::new("Las actualizaciones se comprueban al iniciar.").color(MUTED));
        }
        ui.add_space(24.0);
        ui.separator();
        ui.label(
            RichText::new(
                "Descarga y reproduce únicamente contenido para el que tengas autorización.",
            )
            .small()
            .color(MUTED),
        );
    }
    fn picker(&mut self, ctx: &egui::Context) {
        let Some(mut p) = self.picker.take() else {
            return;
        };
        let mut open = true;
        let mut action = None;
        egui::Window::new(format!("Episodio {}", p.episode.number))
            .id(egui::Id::new("episode-picker"))
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .default_width(480.0)
            .anchor(egui::Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label(RichText::new(&p.anime.title).size(20.0).strong());
                if let Some(s) = &p.sources {
                    ui.horizontal(|ui| {
                        ui.label("Idioma");
                        for lang in s.languages() {
                            if ui.selectable_label(p.language == lang, &lang).clicked() {
                                p.language = lang;
                                p.index = 0;
                            }
                        }
                    });
                    ui.horizontal(|ui| {
                        if ui
                            .selectable_label(!p.download_tab, "Ver en línea")
                            .clicked()
                        {
                            p.download_tab = false;
                            p.index = 0;
                        }
                        if ui
                            .selectable_label(p.download_tab, "Enlaces de descarga")
                            .clicked()
                        {
                            p.download_tab = true;
                            p.index = 0;
                        }
                    });
                    let servers = if p.download_tab {
                        s.downloads.get(&p.language)
                    } else {
                        s.embeds.get(&p.language)
                    };
                    let servers = servers.cloned().unwrap_or_default();
                    if servers.is_empty() {
                        ui.label("No hay servidores en esta categoría para este idioma.");
                    } else {
                        p.index = p.index.min(servers.len() - 1);
                        egui::ComboBox::from_id_salt("server")
                            .selected_text(&servers[p.index].server)
                            .show_ui(ui, |ui| {
                                for (i, server) in servers.iter().enumerate() {
                                    ui.selectable_value(&mut p.index, i, &server.server);
                                }
                            });
                        ui.add_space(10.0);
                        ui.horizontal(|ui| {
                            if !p.download_tab
                                && ui
                                    .add_enabled(
                                        !self.playing,
                                        egui::Button::new(
                                            RichText::new(if self.playing {
                                                "Abriendo…"
                                            } else {
                                                "Reproducir"
                                            })
                                            .color(CYAN),
                                        ),
                                    )
                                    .clicked()
                            {
                                action = Some((false, servers[p.index].clone()));
                            }
                            if ui.button("Descargar").clicked() {
                                action = Some((true, servers[p.index].clone()));
                            }
                        });
                    }
                } else {
                    ui.horizontal(|ui| {
                        ui.spinner();
                        ui.label("Consultando servidores…");
                    });
                }
            });
        if let Some((download, server)) = action {
            if download {
                self.download(
                    p.anime.clone(),
                    p.episode.clone(),
                    server,
                    p.language.clone(),
                );
            } else {
                self.playing = true;
                self.tasks.play(
                    self.definition.clone(),
                    p.anime.clone(),
                    p.episode.clone(),
                    server,
                    self.state.settings.player.clone(),
                );
            }
        }
        if open {
            self.picker = Some(p);
        } else {
            self.sources_seq += 1;
        }
    }
}
fn toggle(ui: &mut egui::Ui, value: &mut bool) -> egui::Response {
    let (rect, mut response) = ui.allocate_exact_size(egui::vec2(46.0, 26.0), egui::Sense::click());
    if response.clicked() {
        *value = !*value;
        response.mark_changed();
    }
    let visuals = ui.style().interact(&response);
    ui.painter().rect_filled(
        rect,
        13,
        if *value {
            Color32::from_rgb(0, 110, 128)
        } else {
            Color32::from_rgb(85, 87, 107)
        },
    );
    let x = if *value {
        rect.right() - 13.0
    } else {
        rect.left() + 13.0
    };
    ui.painter().circle_filled(
        egui::pos2(x, rect.center().y),
        11.0,
        if *value {
            CYAN
        } else {
            visuals.fg_stroke.color
        },
    );
    response.on_hover_text(if *value {
        "Cancelar descarga"
    } else {
        "Descargar episodio"
    })
}
impl eframe::App for AniLinux {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if ctx.input_mut(|i| {
            i.consume_shortcut(&egui::KeyboardShortcut::new(
                egui::Modifiers::CTRL,
                egui::Key::Q,
            ))
        }) {
            ctx.send_viewport_cmd(egui::ViewportCommand::Close);
        }
        self.poll();
        self.images.poll(ctx);
        self.sidebar(ctx);
        self.header(ctx);
        egui::TopBottomPanel::bottom("notice")
            .frame(egui::Frame::new().fill(PANEL).inner_margin(10))
            .show(ctx, |ui| {
                if let Some((text, time)) = &self.notice {
                    if time.elapsed() < Duration::from_secs(12) {
                        ui.label(RichText::new(text).color(CYAN));
                    } else {
                        ui.label(RichText::new("AniLinux").small().color(MUTED));
                    }
                } else {
                    ui.label(RichText::new("AniLinux").small().color(MUTED));
                }
            });
        egui::CentralPanel::default()
            .frame(egui::Frame::new().fill(BG).inner_margin(22))
            .show(ctx, |ui| {
                if let Some(error) = self.error.clone() {
                    ui.horizontal_wrapped(|ui| {
                        ui.colored_label(Color32::from_rgb(255, 170, 155), error);
                        if ui.button("Reintentar").clicked() {
                            if self.page == Page::Detail {
                                if let Some(a) = self.detail.clone() {
                                    self.open(a);
                                }
                            } else {
                                self.refresh();
                            }
                        }
                    });
                }
                egui::ScrollArea::vertical()
                    .id_salt(format!("page-{}", self.page as u8))
                    .auto_shrink([false, false])
                    .show(ui, |ui| match self.page {
                        Page::Home | Page::Catalog | Page::Releases => self.browse_view(ui),
                        Page::Detail => self.detail_view(ui),
                        Page::Downloads => self.downloads_view(ui),
                        Page::Settings => self.settings_view(ui),
                    });
            });
        self.picker(ctx);
        if self.dirty && self.saved.elapsed() > Duration::from_millis(500) {
            self.tasks.save(&self.state);
            self.dirty = false;
            self.saved = Instant::now();
        }
        if self.loading
            || self.detail_loading
            || self.playing
            || !self.jobs.is_empty()
            || self.dirty
            || self
                .notice
                .as_ref()
                .is_some_and(|(_, t)| t.elapsed() < Duration::from_secs(12))
        {
            ctx.request_repaint_after(Duration::from_millis(150));
        }
    }
    fn on_exit(&mut self, _gl: Option<&eframe::glow::Context>) {
        for cancel in self.jobs.values() {
            cancel.cancel();
        }
        if let Ok(mut snapshot) = self.final_state.lock() {
            *snapshot = self.state.clone();
        }
    }
}
