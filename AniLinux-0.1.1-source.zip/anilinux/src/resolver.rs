use crate::{extension_manager::Definition, models::Server, network};
use anyhow::{bail, ensure, Context, Result};
use serde_json::Value;
use std::{collections::BTreeMap, process::Stdio, time::Duration};

#[derive(Clone, Debug)]
pub enum MediaKind {
    Direct,
    Hls,
}
#[derive(Clone, Debug)]
pub struct Media {
    pub url: String,
    pub referer: String,
    pub headers: BTreeMap<String, String>,
    pub kind: MediaKind,
}
pub fn installed(name: &str) -> bool {
    std::env::var_os("PATH").is_some_and(|paths| {
        std::env::split_paths(&paths).any(|p| {
            use std::os::unix::fs::PermissionsExt;
            std::fs::metadata(p.join(name))
                .is_ok_and(|m| m.is_file() && m.permissions().mode() & 0o111 != 0)
        })
    })
}
pub async fn resolve(
    client: &reqwest::Client,
    d: &Definition,
    server: &Server,
    referer: &str,
) -> Result<Media> {
    let url = network::web_url(&server.url)?;
    let mut media = Media {
        url: url.to_string(),
        referer: referer.into(),
        headers: BTreeMap::new(),
        kind: MediaKind::Direct,
    };
    for rule in &d.resolvers {
        if url.host_str() != Some(rule.host.as_str()) {
            continue;
        }
        let re = regex::Regex::new(&rule.path_pattern)?;
        if !re.is_match(url.path()) {
            continue;
        }
        let mut target = url.clone();
        target.set_path(&re.replace(url.path(), rule.replacement.as_str()));
        target.set_query(None);
        target.set_fragment(None);
        media.url = target.to_string();
        media.referer = url.to_string();
        if rule.kind == "hls" {
            let data = network::bytes(client, &media.url, &media.referer, 1024 * 1024).await?;
            ensure!(
                String::from_utf8_lossy(&data)
                    .trim_start_matches('\u{feff}')
                    .trim_start()
                    .starts_with("#EXTM3U"),
                "El servidor no entregó un vídeo disponible"
            );
            media.kind = MediaKind::Hls;
        }
        return Ok(media);
    }
    let path = url.path().to_ascii_lowercase();
    if path.ends_with(".m3u8") {
        media.kind = MediaKind::Hls;
        return Ok(media);
    }
    if [".mp4", ".mkv", ".webm", ".m4v"]
        .iter()
        .any(|ext| path.ends_with(ext))
    {
        return Ok(media);
    }
    ensure!(
        installed("yt-dlp"),
        "Este servidor necesita yt-dlp. Instálalo o elige otro servidor"
    );
    // No shell and no remote code, config files, playlists or credentials.
    let mut cmd = tokio::process::Command::new("yt-dlp");
    cmd.args([
        "--ignore-config",
        "--no-playlist",
        "--no-warnings",
        "--no-call-home",
        "--socket-timeout",
        "20",
        "-f",
        "best",
        "--dump-single-json",
        "--referer",
        referer,
        "--user-agent",
        network::USER_AGENT,
        "--",
        &server.url,
    ])
    .stdin(Stdio::null())
    .kill_on_drop(true);
    let output = tokio::time::timeout(Duration::from_secs(75), cmd.output())
        .await
        .context("El servidor tardó demasiado en responder")??;
    ensure!(
        output.status.success(),
        "No se pudo resolver este servidor; prueba con otro o actualiza yt-dlp"
    );
    ensure!(
        output.stdout.len() < 4 * 1024 * 1024,
        "Respuesta de servidor demasiado grande"
    );
    let data: Value = serde_json::from_slice(&output.stdout)?;
    let Some(link) = data["url"].as_str() else {
        bail!("Este servidor no ofrece un formato de vídeo compatible");
    };
    network::web_url(link)?;
    media.url = link.into();
    if let Some(headers) = data["http_headers"].as_object() {
        for (key, value) in headers {
            let Some(value) = value.as_str() else {
                continue;
            };
            reqwest::header::HeaderName::from_bytes(key.as_bytes())?;
            reqwest::header::HeaderValue::from_str(value)?;
            if key.eq_ignore_ascii_case("referer") {
                media.referer = value.into();
            } else {
                media.headers.insert(key.clone(), value.into());
            }
        }
    }
    let protocol = data["protocol"].as_str().unwrap_or("");
    if protocol.contains("m3u8") || link.contains(".m3u8") {
        media.kind = MediaKind::Hls;
    }
    Ok(media)
}
